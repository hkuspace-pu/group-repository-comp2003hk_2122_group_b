# config file containing credentials for RDS MySQL instance
db_endpoint = "tree-db.c2i34jeq5e09.us-east-1.rds.amazonaws.com"
db_username = "admin"
db_password = "Svnny4ever"
db_database = "COMP2003HK_GROUP_B"
